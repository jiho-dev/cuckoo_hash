#ifndef __LF_CUCKOO_H__
#define __LF_CUCKOO_H__

#include <stdint.h>

#define MAX_COUNTER 281474976710656
#define FIRST       1
#define SECOND      2
#define NIL         -1

typedef struct entry_s {
	int			key;
	void		*value;
	uint16_t	count;
	uint16_t	dummy;
} entry_t;


typedef struct cuckooHashTable_s {
	entry_t *table1;
	entry_t *table2;
	//atomic < entry_t * > *table1;
	//atomic < entry_t * > *table2;

	int		t1Size;
	int		t2Size;
} cuckooHashTable_t;

#endif
