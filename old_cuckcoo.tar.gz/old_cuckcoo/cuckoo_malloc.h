#ifndef __CUCKOO_MALLOC_H__
#define __CUCKOO_MALLOC_H__

#ifdef __KERNEL__

#else
#include <stdlib.h>

#endif

static inline void* cuckoo_malloc(size_t len)
{
#ifdef __KERNEL__

#else
	return malloc(len);
#endif
}

static inline void cuckoo_free(void *mem)
{
#ifdef __KERNEL__

#else
	free(mem);
#endif
}

#endif
